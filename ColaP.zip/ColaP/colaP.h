#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#ifndef _COLAP_H_
#define _COLAP_H_

/*
 * Estructura que guarda el nodo, un puntero que apunta a la Info,
 * y otro que apunta al nodo siguiente
 */
typedef struct nodo {
  int num;
  int prio;
  struct nodo *sgte;
}Nodo;

/*
 * Estructura que guarda la Cola, con un puntero que apunta al inicio
 * y al fin de ésta.
 */
typedef struct colaP {
  Nodo *ini;
  Nodo *fin;
}ColaP;

/* Funciones de las operaciones básicas */
ColaP *crearColaP();
void destruirColaP(ColaP *cp);
Nodo *crearNodo(int num, int prio);
void encolar(ColaP* cp, int num, int prio);
void ordenarColaP(ColaP *cp);
void mostrarcola(ColaP *cp);
int desencolarPrio(ColaP *cp);



#endif /* _COLAP_H_ */
