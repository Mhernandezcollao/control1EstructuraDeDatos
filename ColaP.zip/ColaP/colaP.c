#include "colaP.h"

/*
 * Función que permite crear una nueva cola vacía.
 */

ColaP *crearColaP()
{
  ColaP *nueva;

  if(nueva = (ColaP *) malloc(sizeof(ColaP))) // Pide memoria para la Cola
    {
      nueva->ini = nueva->fin = NULL; // Inicio y Fin apuntan a NULL
    }
  return nueva;
}

/*
 * Función que permite eliminar una Cola.
 */

void destruirColaP(ColaP *cp)
{
  Nodo *aux;

  while(cp->ini != NULL)
    {
      aux = cp->ini;
      cp->ini = cp->ini->sgte;
      free(aux);
    }
	free(cp);
}

/*
 * Función que crea un nodo
 */

Nodo *crearNodo(int num, int prio)
{
  Nodo *nuevo;
  nuevo = (Nodo *) malloc(sizeof(Nodo)); // Pide memoria para el nodo
    
      nuevo->num = num;
      nuevo->prio = prio;
    
  return nuevo;
}

/*
 * Funcion que encola y a la vez los ordena de mayor prioridad a menor.
 */

void encolar(ColaP* cp, int num, int prio)
{
  Nodo *aux = crearNodo( num, prio );

  if( cp->ini == NULL ){
    cp->ini = aux;
    cp->fin = aux;
  }else{
    (cp->fin)->sgte = aux;
    cp->fin = aux;
	}

	ordenarColaP(cp);
}

/*
 * Función que ordena la cola por prioridad.
 * Siendo la mayor prioridad 1
 */

void ordenarColaP(ColaP *cp){
  
  Nodo *aux1, *aux2;
  int numAux,
      prioAux;
      
  aux1 = cp->ini;
  
  while( aux1->sgte != NULL ){
    
    aux2 = aux1->sgte;
    
    while( aux2 != NULL ){
      
      if( aux1->prio > aux2->prio ){
		numAux  = aux1->num;
		prioAux = aux1->prio;
	
		aux1->num  = aux2->num;
		aux1->prio = aux2->prio;
	
		aux2->num = numAux;
		aux2->prio = prioAux;
      }
      
      aux2 = aux2->sgte;
    }
    
    aux1 = aux1->sgte;
  }
  
}

/*
 * Función que muestra la cola.
 */
void mostrarcola(ColaP *cp){
  Nodo *nodoAux = cp->ini;
  
  while( nodoAux != NULL ){
    printf("%d, Con Prioridad: %d", nodoAux->num, nodoAux->prio);
    printf("\n");
    nodoAux = nodoAux->sgte;
  }
  printf("\n");

}

/*
 * Función que elimina la prioridad
 */
int desencolarPrio(ColaP *cp){

  int x = (cp->ini)->num;
  
  Nodo *nodoAux = (cp->ini);
  
  cp->ini = (cp->ini)->sgte;
  
  free(cp);
  
  return x;
}


/**
 * Función Principal
 *
 */
int main(int argc, char *argv[])
{
  ColaP *CP;
  CP = crearColaP();

	encolar(CP, 7, 3);
	encolar(CP, 9, 6);
	encolar(CP, 1, 4);
	encolar(CP, 0, 10);
	encolar(CP, 5, 1);
	mostrarcola(CP);
	printf ("Desencolando el de Mayor Prioridad: %d", desencolarPrio(CP));
	mostrarcola(CP);

}